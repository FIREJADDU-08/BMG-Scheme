import TextDefault from './TextDefault/TextDefault'

export { TextDefault }
